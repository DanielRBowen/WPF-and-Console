/* A simple server in the internet domain using TCP
   The port number is passed as an argument */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <string>
#include <unistd.h>
#include <sys/types.h> 
#include <sys/socket.h>
#include <netinet/in.h>
#include "server.h"
#include <iostream>
#include <cstdlib>
#include <list>
#include <vector>
#include <algorithm>
#include <boost/lexical_cast.hpp>
#include <boost/asio.hpp>
#include <boost/bind.hpp>
#include <boost/ptr_container/ptr_list.hpp>
#include <boost/thread.hpp>
#include <ctime>
#include <iostream>
#include <string>
#include <boost/bind.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/enable_shared_from_this.hpp>
#include <boost/asio.hpp>

using boost::asio::ip::tcp;

std::string make_daytime_string()
{
  using namespace std; // For time_t, time and ctime;
  time_t now = time(0);
  return ctime(&now);
}

class tcp_connection
  : public boost::enable_shared_from_this<tcp_connection>
{
public:
  typedef boost::shared_ptr<tcp_connection> pointer;

  static pointer create(boost::asio::io_service& io_service)
  {
    return pointer(new tcp_connection(io_service));
  }

  tcp::socket& socket()
  {
    return socket_;
  }

  void start()
  {
    message_ = make_daytime_string();

    boost::asio::async_write(socket_, boost::asio::buffer(message_),
        boost::bind(&tcp_connection::handle_write, shared_from_this(),
          boost::asio::placeholders::error,
          boost::asio::placeholders::bytes_transferred));
  }

private:
  tcp_connection(boost::asio::io_service& io_service)
    : socket_(io_service)
  {
  }

  void handle_write(const boost::system::error_code& /*error*/,
      size_t /*bytes_transferred*/)
  {
  }

  tcp::socket socket_;
  std::string message_;
};

class tcp_server
{
public:
  tcp_server(boost::asio::io_service& io_service)
    : acceptor_(io_service, tcp::endpoint(tcp::v4(), 13))
  {
    start_accept();
  }

private:
  void start_accept()
  {
    tcp_connection::pointer new_connection =
      tcp_connection::create(acceptor_.io_service());

    acceptor_.async_accept(new_connection->socket(),
        boost::bind(&tcp_server::handle_accept, this, new_connection,
          boost::asio::placeholders::error));
  }

  void handle_accept(tcp_connection::pointer new_connection,
      const boost::system::error_code& error)
  {
    if (!error)
    {
      new_connection->start();
      start_accept();
    }
  }

  tcp::acceptor acceptor_;
};


void error(const char *msg)
{
    perror(msg);
    exit(1);
}

std::vector<spreadsheet> spreadsheets; // contains all the spreadsheets

int main(int argc, char *argv[])
{
	
     int sockfd, newsockfd, portno;
     socklen_t clilen;
     char buffer[256];
     char buff[256];
     char buff_fail[256];
    
     struct sockaddr_in serv_addr, cli_addr;
     int n;
     if (argc < 2) {
         fprintf(stderr,"ERROR, no port provided\n");
         exit(1);
     }
     sockfd = socket(AF_INET, SOCK_STREAM, 0);
     if (sockfd < 0) 
        error("ERROR opening socket");
     bzero((char *) &serv_addr, sizeof(serv_addr));
     portno = atoi(argv[1]);
     serv_addr.sin_family = AF_INET;
     serv_addr.sin_addr.s_addr = INADDR_ANY;
     serv_addr.sin_port = htons(portno);
     if (bind(sockfd, (struct sockaddr *) &serv_addr,
              sizeof(serv_addr)) < 0) 
              error("ERROR on binding");

     while(true)
       {
	 listen(sockfd,5);
	 clilen = sizeof(cli_addr);
	 newsockfd = accept(sockfd, 
			    (struct sockaddr *) &cli_addr, 
			    &clilen);
	 if (newsockfd < 0) 
	   error("ERROR on accept");
	 bzero(buffer,256);
	 n = read(newsockfd,buffer,255);
	 if (n < 0) error("ERROR reading from socket");
	 if (n < 0)
	   {
	     error("ERROR writing to socket");
	     break;
	   }

	 std::string temp = buffer;
	 std::string (str[30]);
	 int m = 0;
	 std::string del = "\n";
	 size_t pos = 0;
	 std::string tok;
	 // template<class T, class Alloc = allocator<T>>class vector;
	 //get rid of colons
	 while((pos=temp.find(":")) != std::string::npos)
	   {
	     temp.replace(pos, 1, "\n");
	   }
	 //separate by \n put into string array str
	 while ((pos = temp.find(del)) != std::string::npos)
	   {
	     tok = temp.substr(0, pos);
	     str[m] = tok;
	     //std::cout << tok << "|";
	     temp.erase(0, pos + del.length());
	     m++;
	   }
	/* std::cout <<  "user's socket" << newsockfd << std::endl;
	  for (int i=0; i < m; i++)
	   {
	     std::cout << "\n" << str[i];
	   }
	 std::cout << std::endl;
	 /*switch*/
	 if(strncmp(str[0].c_str(), "CREATE", 5) == 0)
	   {
		   //printf("In the Create method\n");
		 if (!spreadsheetExists(str[2]))
		 {
			// create the spreadsheet
			spreadsheet temp(str[2], str[4]);
			spreadsheets.push_back(temp);
			// send success message
			bzero(buff,256);
			int len = strlen(buff);
			strcpy(buff, "CREATE OK");
			len = strlen(buff);
			buff[len] = 0xa;
			strcat(buff, "Name:");
			strcat(buff, str[2].c_str());
			len = strlen(buff);
			buff[len] = 0xa;
			strcat(buff, "Password:");
			strcat(buff, str[4].c_str());
			len = strlen(buff);
			buff[len] = 0xa;
			buff[len+1] = 0;
			n = write(newsockfd, buff, strlen(buff));
		}
		else
		{
			bzero(buff_fail,256);
			int lenf = strlen(buff_fail);
			strcpy(buff_fail, "CREATE FAIL");
			lenf = strlen(buff_fail);
			buff_fail[lenf] = 0xa;
			strcat(buff_fail, "Name:");
			strcat(buff_fail, str[2].c_str());
			lenf = strlen(buff_fail);
			buff_fail[lenf] = 0xa;
			strcat(buff_fail, "Password:");
			strcat(buff_fail, str[4].c_str());
			lenf = strlen(buff_fail);
			buff_fail[lenf] = 0xa;
			buff_fail[lenf+1] = 0;
			n = write(newsockfd, buff_fail, strlen(buff_fail));
		}
	   }
	 else if (strncmp(buffer, "JOIN", 4) == 0)
	   {
		  // std::cout<<"In the JOIN method"<<std::endl;
		 if (!spreadsheetExists(str[2])) // check to find spreadsheet
		 {
			 // send error message that spreadsheet name is invalid
			  char bufferj[256];
			 // send correct message
			 
			bzero(bufferj,256);
			int lenj = strlen(bufferj);
			strcpy(bufferj, "JOIN FAIL");
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Name:");
			strcat(bufferj, str[2].c_str());
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Message:Spreadsheet doesn't exist.");
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			bufferj[lenj+1] = 0;
			n = write(newsockfd, bufferj, strlen(bufferj));
		 }
		 else if (!correctPassword(str[2], str[4])) // check if password is correct
		 {
			 // send error message that password is incorrect
			 // JOIN SP FAIL\nName:name\nPassword is incorrect\n
			 char bufferj[256];
			 // send correct message
			 
			bzero(bufferj,256);
			int lenj = strlen(bufferj);
			strcpy(bufferj, "JOIN FAIL");
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Name:");
			strcat(bufferj, str[2].c_str());
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Message:Incorrect password.");
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			bufferj[lenj+1] = 0;
			n = write(newsockfd, bufferj, strlen(bufferj));
		 }
		 else // spreadsheet and password were correct proceed
		 {
			 spreadsheet* temp = findSpreadsheet(str[2]);
			 std::string xml = temp->writeXML();
			 temp->verCheck();
			 int ver = temp->version;
			 temp->addUser(newsockfd);
			// Converts int ver to string
		     std::string versNum = boost::lexical_cast<std::string>(ver);
			 int leng = strlen(xml.c_str());
			 std::string lengt = boost::lexical_cast<std::string>(leng);
			 char bufferj[256];
			 // send correct message
			 
			bzero(bufferj,256);
			int lenj = strlen(bufferj);
			strcpy(bufferj, "JOIN OK");
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Name:");
			strcat(bufferj, str[2].c_str());
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Version:");
			
			strcat(bufferj, versNum.c_str());   //Get version #
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Length:");
			strcat(bufferj, lengt.c_str()); // Length of content
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, xml.c_str());
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			bufferj[lenj+1] = 0;
			n = write(newsockfd, bufferj, strlen(bufferj));
			 // need to add user to spreadsheet
			 
		 }
	   }
	   
	  else if(strncmp(str[0].c_str(), "CHANGE", 6) == 0)
	   {
		   // grab spreadsheet
		  //std::cout <<  "In change" << str[0].c_str() << std::endl;
			spreadsheet* temp = findSpreadsheet(str[2]);
			int ver = std::stoi(str[4]); // convert the version to an int
			// see if user is editing that spreadsheet
			if(!temp->userExists(newsockfd))
			{
				// send error message
				// user isn't editing this spreadsheet
				//std::cout <<  "user isn't editing this spreadsheet\n" << newsockfd << std::endl;
				//printf("user isn't editing this spreadsheet\n");
				//std::cout<<newsockfd<<std::endl;
				
				 char bufferj[256];
			 // send correct message
			 
			bzero(bufferj,256);
			int lenj = strlen(bufferj);
			strcpy(bufferj, "CHANGE FAIL");
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Name:");
			strcat(bufferj, str[2].c_str());
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Message:User doesn't exist.");
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			bufferj[lenj+1] = 0;
			n = write(newsockfd, bufferj, strlen(bufferj));
			}
			else if(!temp->checkVersionNumber(ver))
		   {
			   // send out of date version message
			   // CHANGE SP WAIT\nName:name\nVersion:version\n
			   //printf("version out of date\n");
			    
			    char bufferj[256];
			 // send correct message
			 
			bzero(bufferj,256);
			int lenj = strlen(bufferj);
			strcpy(bufferj, "CHANGE WAIT");
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Name:");
			strcat(bufferj, str[2].c_str());
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Version:Version is out of date.");
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			bufferj[lenj+1] = 0;
			n = write(newsockfd, bufferj, strlen(bufferj));
		   }
		   else // confirmed change make the change, send the change, confirm the change
		   {
			   if (temp->cellExists(str[6]))
			   {
				   temp->updateCell(str[6], str[9]);
				  // printf("Cell is %s\n ", str[9].c_str());
			   }
			   else
			   {
				   temp->insertCell(str[6], str[9]);
			   }
			   temp->version = temp->version++;
			   std::vector<int> sockets = temp->getUsers();
			   
			   for (std::vector<int>::size_type i = 0; i != sockets.size(); i++)
				{
					if (sockets[i] != newsockfd)
					{
						// something with socket[i] here
						// send UPDATE to all other users
						 char bufferj[256];
						 // send correct message
						 std::string versionNumb = boost::lexical_cast<std::string>(temp->version);
						bzero(bufferj,256);
						int lenj = strlen(bufferj);
						strcpy(bufferj, "UPDATE");
						lenj = strlen(bufferj);
						bufferj[lenj] = 0xa;
						strcat(bufferj, "Name:");
						strcat(bufferj, str[2].c_str());
						lenj = strlen(bufferj);
						bufferj[lenj] = 0xa;
						strcat(bufferj, "Version:");
						strcat(bufferj, versionNumb.c_str());
						lenj = strlen(bufferj);
						bufferj[lenj] = 0xa;
						strcat(bufferj, "Cell:");
						strcat(bufferj, str[6].c_str()); //Cell
						lenj = strlen(bufferj);
						bufferj[lenj] = 0xa;
						strcat(bufferj, "Length:");
						strcat(bufferj, str[8].c_str());//Length
						lenj = strlen(bufferj);
						bufferj[lenj] = 0xa;
						strcat(bufferj, str[9].c_str());//Content
						lenj = strlen(bufferj);
						bufferj[lenj] = 0xa;
						bufferj[lenj+1] = 0;
						n = write(newsockfd, bufferj, strlen(bufferj));
					}
				}
				char bufferj[256];
			// send correct message
			std::string versionNum = boost::lexical_cast<std::string>(temp->version);
			 
			bzero(bufferj,256);
			int lenj = strlen(bufferj);
			strcpy(bufferj, "CHANGE OK");
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Name:");
			strcat(bufferj, str[2].c_str());
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			strcat(bufferj, "Version:");
			strcat(bufferj, versionNum.c_str());   //Get version #
			lenj = strlen(bufferj);
			bufferj[lenj] = 0xa;
			bufferj[lenj+1] = 0;
			n = write(newsockfd, bufferj, strlen(bufferj));
				
		   }
		   
	   }
	   else if(strncmp(str[0].c_str(), "UNDO", 4) == 0)
	   {
		  // std::cout<<"In undo"<<std::endl;
		   // grab spreadsheet
			spreadsheet* temp = findSpreadsheet(str[2]);
			int ver = std::stoi(str[4]); // convert the version to an int
			// see if user is editing that spreadsheet
				if(!temp->userExists(newsockfd))
				{
				// send error message
				// user isn't editing this spreadsheet
				//printf("user isn't editing this spreadsheet\n");
				
				char bufferj[256];
				// send correct message
					
				bzero(bufferj,256);
				int lenj = strlen(bufferj);
				strcpy(bufferj, "UNDO FAIL");
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Name:");
				strcat(bufferj, str[2].c_str());
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Message:User doesn't exist.");
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				bufferj[lenj+1] = 0;
				n = write(newsockfd, bufferj, strlen(bufferj));
				}
				else if(!temp->checkVersionNumber(ver))
			   {
				   // send out of date version message
				   // CHANGE SP WAIT\nName:name\nVersion:version\n
				 //  printf("version out of date\n");
					std::string versionNum = boost::lexical_cast<std::string>(temp->version);
					char bufferj[256];
				 // send correct message
				 
				bzero(bufferj,256);
				int lenj = strlen(bufferj);
				strcpy(bufferj, "UNDO WAIT");
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Name:");
				strcat(bufferj, str[2].c_str());
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Version:");
				strcat(bufferj, versionNum.c_str());   //Get version #
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				bufferj[lenj+1] = 0;
				n = write(newsockfd, bufferj, strlen(bufferj));
				}
				else if(!temp->canUndo())//Nothing to save
				{
					std::string versionNum = boost::lexical_cast<std::string>(temp->version);
					char bufferj[256];
				 // send correct message
				 
				bzero(bufferj,256);
				int lenj = strlen(bufferj);
				strcpy(bufferj, "UNDO END");
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Name:");
				strcat(bufferj, str[2].c_str());
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Version:");
				strcat(bufferj, versionNum.c_str());   //Get version #
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				bufferj[lenj+1] = 0;
				n = write(newsockfd, bufferj, strlen(bufferj));
				}
				else // confirmed change make the change, send the change, confirm the change
				{
					//undo last change
					temp->version = temp->version++;
					std::vector<int> sockets = temp->getUsers();
					for (std::vector<int>::size_type i = 0; i != sockets.size(); i++)
					{
						if (sockets[i] != newsockfd)
						{
							// something with socket[i] here
							// send UPDATE to all other users
							 char bufferj[256];
							 // send correct message
							 std::string versionNumb = boost::lexical_cast<std::string>(temp->version);
							bzero(bufferj,256);
							int lenj = strlen(bufferj);
							strcpy(bufferj, "UPDATE");
							lenj = strlen(bufferj);
							bufferj[lenj] = 0xa;
							strcat(bufferj, "Name:");
							strcat(bufferj, str[2].c_str());
							lenj = strlen(bufferj);
							bufferj[lenj] = 0xa;
							strcat(bufferj, "Version:");
							strcat(bufferj, versionNumb.c_str());
							lenj = strlen(bufferj);
							bufferj[lenj] = 0xa;
							strcat(bufferj, "Cell:");
							strcat(bufferj, str[6].c_str()); //Cell
							lenj = strlen(bufferj);
							bufferj[lenj] = 0xa;
							strcat(bufferj, "Length:");
							strcat(bufferj, str[8].c_str());//Length
							lenj = strlen(bufferj);
							bufferj[lenj] = 0xa; //GET THE CELL FROM UNDO
							strcat(bufferj, str[9].c_str());//Content
							lenj = strlen(bufferj); // GET LENGTH
							bufferj[lenj] = 0xa;     // GET CONTENT FROM UNDO
							bufferj[lenj+1] = 0;
							n = write(newsockfd, bufferj, strlen(bufferj));
						}
					
					
					}
				char bufferj[256];
				// send correct message
				std::string versionNum = boost::lexical_cast<std::string>(temp->version);
				 
				bzero(bufferj,256);
				int lenj = strlen(bufferj);
				strcpy(bufferj, "UNDO OK");
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Name:");
				strcat(bufferj, str[2].c_str());
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Version:");
				strcat(bufferj, versionNum.c_str());   //Get version #
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Cell:");
				strcat(bufferj, str[6].c_str()); //Cell
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Length:");		// GET CELL, LENGTH AND CONTENT FROM UNDO
				strcat(bufferj, str[8].c_str());//Length
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, str[9].c_str());//Content
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				bufferj[lenj+1] = 0;
				n = write(newsockfd, bufferj, strlen(bufferj));
				 }
			
	   }
	   else if(strncmp(str[0].c_str(), "SAVE", 4) == 0)
	   {
		    // grab spreadsheet
			spreadsheet* temp = findSpreadsheet(str[2]);
			
			// see if user is editing that spreadsheet
			if(!temp->userExists(newsockfd))
			{
				// send error message
				// user isn't editing this spreadsheet
				//printf("client can't SAVE because not a user of spreadsheet\n");
				
				 char bufferj[256];
					// send correct message
			 
				bzero(bufferj,256);
				int lenj = strlen(bufferj);
				strcpy(bufferj, "SAVE FAIL");
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Name:");
				strcat(bufferj, str[2].c_str());
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Message:User doesn't exist.");
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				bufferj[lenj+1] = 0;
				n = write(newsockfd, bufferj, strlen(bufferj));
			}
			else
			{
				spreadsheet* temp = findSpreadsheet(str[2]);
				temp->saveFile(str[2]);
				//Save current state of SS to file
				//Once a SS is created we should save it 
				//Pop all off the 'UNDO' stack
				 char bufferj[256];
				
				// Send confirmation back to client	 
				bzero(bufferj,256);
				int lenj = strlen(bufferj);
				strcpy(bufferj, "SAVE OK");
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				strcat(bufferj, "Name:");
				strcat(bufferj, str[2].c_str());
				lenj = strlen(bufferj);
				bufferj[lenj] = 0xa;
				bufferj[lenj+1] = 0;
				n = write(newsockfd, bufferj, strlen(bufferj));
			}
		   
	   }
	   else if(strncmp(str[0].c_str(), "LEAVE", 5) == 0)
	   {
		   //Server doesn't respond
		   spreadsheet* temp = findSpreadsheet(str[2]);
		   temp->removeUser(newsockfd);
	   }
	  else
	  {
	   // printf("Didn't get the create command %s\n", buffer);
	    char bufferj[256];
		
		// Send ERROR back
		bzero(bufferj,256);
		int lenj = strlen(bufferj);
		strcpy(bufferj, "ERROR");
		lenj = strlen(bufferj);
		bufferj[lenj] = 0xa;
		bufferj[lenj+1] = 0;
		n = write(newsockfd, bufferj, strlen(bufferj));
	   }
     }

     close(newsockfd);
     close(sockfd);
     return 0;
}



spreadsheet* findSpreadsheet(std::string name)
{
		for (std::vector<spreadsheet>::size_type i = 0; i != spreadsheets.size(); i++)
	     {
			if (spreadsheets[i].name == name) // check to see if we already have that spreadsheet
			{
				return &spreadsheets[i];
			}
		 }
		 return NULL;
}

bool spreadsheetExists(std::string name)
{
		for (std::vector<spreadsheet>::size_type i = 0; i != spreadsheets.size(); i++)
	     {
			if (spreadsheets[i].name == name) // check to see if we already have that spreadsheet
			{
				return true;
			}
		 }
		 return false;
}

bool correctPassword(std::string name, std::string pswd)
{
		for (std::vector<spreadsheet>::size_type i = 0; i != spreadsheets.size(); i++)
	     {
			if (spreadsheets[i].name == name && spreadsheets[i].password == pswd) // check to see if we already have that spreadsheet
			{
				return true;
			}
		 }
		 return false;
}


