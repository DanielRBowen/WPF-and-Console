#include <boost/regex.hpp>

#include <boost/lexical_cast.hpp>
#include <cstdlib>
#include <iostream>
#include <boost/bind.hpp>
#include <boost/asio.hpp>
#include <boost/ptr_container/ptr_list.hpp>
#include <boost/thread.hpp>
#include "server.h"
#include "spreadsheet.h"
#include <list>
#include <stack>
#include <string>
#include <sstream>
#include <algorithm>
#include <iterator>
#include <fstream>

using boost::asio::ip::tcp;
using boost::mutex;
boost:: mutex;
typedef boost::shared_ptr<spreadsheet::spreadsheet> spreadsheet_ptr;
session::session(boost::asio::io_service& io_service)
:socket_(io_service)
{
name = "None";
}
 
tcp::socket& session::socket()
{
return socket_;
}
 
void session::start()
{
std::cout << "Client Connected, Waiting for message" << std::endl;
boost::asio::async_read_until(socket_, response_, '\n',
boost::bind(&session::handle_header, this,
boost::asio::placeholders::error,
boost::asio::placeholders::bytes_transferred));
}
 
void session::handle_header(const boost::system::error_code& error,
size_t bytes_transferred)
{
if (!error)
{
std::istream response_stream(&response_);
std::string message;
std::getline(response_stream, message);
std::cout << "Header:" << message << std::endl;
 
if(message == "CHANGE")
{
boost::asio::async_read_until(socket_, response_, '\n',
boost::bind(&session::handle_change_name, this,
boost::asio::placeholders::error,
boost::asio::placeholders::bytes_transferred));
}
else if(message == "CREATE")
{
boost::asio::async_read_until(socket_, response_, '\n',
boost::bind(&session::handle_create_name, this,
boost::asio::placeholders::error,
boost::asio::placeholders::bytes_transferred));
 
}
else if (message == "JOIN")
{
boost::asio::async_read_until(socket_, response_, '\n',
boost::bind(&session::handle_join_name, this,
boost::asio::placeholders::error,
boost::asio::placeholders::bytes_transferred));
}
else if (message == "LEAVE")
{
boost::asio::async_read_until(socket_, response_, '\n',
boost::bind(&session::handle_leave_name, this,
boost::asio::placeholders::error,
boost::asio::placeholders::bytes_transferred));
 
}
else if (message == "SAVE")
{
boost::asio::async_read_until(socket_, response_, '\n',
boost::bind(&session::handle_save_name, this,
boost::asio::placeholders::error,
boost::asio::placeholders::bytes_transferred));
}
else if (message == "UNDO")
{
boost::asio::async_read_until(socket_, response_, '\n',
boost::bind(&session::handle_undo_name, this,
boost::asio::placeholders::error,
boost::asio::placeholders::bytes_transferred));
}
else
{
std::string error = "ERROR\n";
send_message(error);
}
}
else
{
std::cout << "ERROR In handle_header" << std::endl;
delete this;
}
}
 
