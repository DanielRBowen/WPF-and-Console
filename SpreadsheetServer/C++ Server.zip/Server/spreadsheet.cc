#include "spreadsheet.h"
#include <iostream>
#include <string>
#include <stack>
#include <array>
#include <vector>
#include <fstream>

// unused constructor
spreadsheet::spreadsheet()
{
}

// constructor
spreadsheet::spreadsheet(std::string nm, std::string pswd)
{
	this->name = nm;
	this->password = pswd;
	this->version = 0; // unsure about this
	this->users.push_back(1);
}

// return all sockets for the spreadsheet
std::vector<int> spreadsheet::getUsers()
{
	return users;
}

// return true if that socket is editing this spreadsheet
bool spreadsheet::userExists(int user)
{
	for (std::vector<int>::size_type i = 0; i != users.size(); i++)
	     {
			if (users[i] == user)
			{
				return true;
			}
		 }
		 return false;
}

// add this socket to editing this spreadsheet
void spreadsheet::addUser(int user)
{
	users.push_back(user);
}

void spreadsheet::removeUser(int user)
{
	for (std::vector<int>::size_type i = 0; i != users.size(); i++)
	     {
			if (users[i] == user) // check to see if we already have that cell
			{
				users.erase(users.begin() + i);
			}
		 }
	if (users.size() == 0)
		this->saveFile(this->name);
}

// returns true if the version numbers are the same
bool spreadsheet::checkVersionNumber(int ver)
{
	if (ver == this->version)
		return true;
	else
		return false;
}

bool spreadsheet::cellExists(std::string cell)
{
	for (std::vector<std::pair<std::string, std::string>>::size_type i = 0; i != cells.size(); i++)
	     {
			if (cells[i].first == cell) // check to see if we already have that cell
			{
				return true;
			}
		 }
		 return false;
}

void spreadsheet::updateCell(std::string cell, std::string contents)
{
	std::pair <std::string, std::string> undoCell;
	for (std::vector<std::pair<std::string, std::string>>::size_type i = 0; i != cells.size(); i++)
	     {
			if (cells[i].first == cell) // check to see if we already have that cell
			{
				undoCell = cells[i];
				cells.erase(cells.begin() + i);
			}
		 }
		 std::pair <std::string, std::string> temp (cell, contents);
		 undo.push(undoCell);
		 cells.push_back(temp);
}

void spreadsheet::insertCell(std::string cell, std::string contents)
{
	std::pair <std::string, std::string> temp (cell, contents);
	std::pair <std::string, std::string> undoCell (cell, "");
	undo.push(undoCell);
	cells.push_back(temp);
}

std::string spreadsheet::writeXML()
{
	std::string xml;
	xml.append("<?xml version=\"1.0\" encoding=\"utf-8\"?><spreadsheet version=\"ps6\">");
	for (std::vector<std::pair<std::string, std::string>>::size_type i = 0; i != cells.size(); i++)
	     {
			 xml.append("<cell><name>");
			 xml.append(cells[i].first);
			 xml.append("</name><contents>");
			 xml.append(cells[i].second);
			 xml.append("</contents></cell>");
		 }
	xml.append("</spreadsheet>");
	return xml;
}

void spreadsheet::verCheck()
{
	if (users.size() == 0)
		this->version = 0;
}

bool spreadsheet::canUndo()
{
	if (this->undo.empty())
		return false;
	return true;
}

void spreadsheet::undoCell()
{
	std::pair <std::string, std::string> temp = this->undo.top();
	this->undo.pop();
	updateCell(temp.first, temp.second);
}

void spreadsheet::saveFile(std::string nm)
{
	std::ofstream outputFile;
	outputFile.open(nm.append(".ss"));
	outputFile << this->writeXML();
	outputFile.close();
}
