#include <string>
#include <stdlib.h>
#include "spreadsheet.h"

void Create_File(char* buff);
spreadsheet* findSpreadsheet(std::string name);
bool spreadsheetExists(std::string name);
bool correctPassword(std::string name, std::string pswd);
