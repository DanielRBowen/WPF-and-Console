#ifndef SPREADSHEET_H

#define SPREADSHEET_H

#include <iostream>
#include <string>
#include <stack>
#include <array>
#include <set>
#include <vector>

class spreadsheet
  {
public:
	std::string name;
	int version;
	std::string password;
	spreadsheet();
	spreadsheet(std::string nm, std::string pswd);
	std::vector<int> getUsers();
	bool userExists(int user);
	void addUser(int user);
	bool checkVersionNumber(int ver);
	bool cellExists(std::string cell);
	void updateCell(std::string cell, std::string contents);
	void insertCell(std::string cell, std::string contents);
	std::string writeXML();
	void verCheck();
	bool canUndo();
	void undoCell();
	void removeUser(int user);
	void saveFile(std::string nm);
private:
	std::stack <std::pair<std::string, std::string>> undo;
	std::vector<int> users;
	std::vector<std::pair<std::string, std::string>> cells;
	// first is cell second is contents
  };

#endif
